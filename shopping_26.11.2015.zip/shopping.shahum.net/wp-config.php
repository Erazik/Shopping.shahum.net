<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'shahumnet_sh');

/** MySQL database username */
define('DB_USER', 'shahumnet_sh');

/** MySQL database password */
define('DB_PASSWORD', 'vMvBH8zN');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'F[x6aOC1:x[V>IHVs|#y[yp]rl]eFjr]NQ51[he&jkcF%*#xy9L=7Y;@O-xAM]Y=');
define('SECURE_AUTH_KEY',  '*d,Yh()Z0 uRBn96qCa3=!rhO%c?X<D}u<PdP{/ulNtWfgm kL&Cchi-)j>tZ|B?');
define('LOGGED_IN_KEY',    'LRU0[fCf/+ZC-+GM>cbgPSE_b+i,BgtI!@9c=b^I|({gjNs*ggr8g-:DH;3GD89-');
define('NONCE_KEY',        '$UD:>:%*Mj+hVEQEAG6+TSP`|dE+|Gg7pO1F;Hb~iNZ~Z!s$Tgi+So*3/|SB@;Mf');
define('AUTH_SALT',        'My4/Wt8k+$4{y<qfg[:Ra~9V8(4({+kB|sS-S~>If:2-ugNn>aXrGIq9+MbY}MU2');
define('SECURE_AUTH_SALT', 'mRxKpqR1^ICXQ43n%$[%]mS$JTkgfL~B?va[sO.jhg}[tlflLM-c?~CXK`&YMM+@');
define('LOGGED_IN_SALT',   '(h|Nd-M)h0QT2k?(i7p{Hth}0{p19KqL+qW#:0Ir]1DRE9{_EV;1B3}xV4 ASU/|');
define('NONCE_SALT',       '+)(>YJ<g$|ZwQ]zD<za-e;}6V9fmR,:Q|CDoj:.!#?nuM@9d%hAv$OW4//WE1Cr8');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
